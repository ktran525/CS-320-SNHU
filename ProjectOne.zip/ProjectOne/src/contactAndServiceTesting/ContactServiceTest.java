package contactAndServiceTesting;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import contactAndService.Contact;
import contactAndService.ContactService;

public class ContactServiceTest {

    @Test
    void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123456", "Jane", "Smith", "1110005555", "123 Drive St.");
        service.addContact(contact);
        assertEquals(contact, service.getContact("123456"));
    }

    @Test
    void testAddDuplicateContactID() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("123456", "Jane", "Smith", "1110005555", "123 Drive St.");
        Contact contact2 = new Contact("123456", "Emily", "Johnson", "2223334444", "456 Oak Ave.");
        service.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact2));
    }

    @Test
    void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123456", "Jane", "Smith", "1110005555", "123 Drive St.");
        service.addContact(contact);
        service.deleteContact("123456");
        assertNull(service.getContact("123456"));
    }

    @Test
    void testDeleteContactNotFound() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("999999"));
    }

    @Test
    void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123456", "Jane", "Smith", "1110005555", "123 Drive St.");
        service.addContact(contact);
        service.updateFirstName("123456", "Emily");
        assertEquals("Emily", service.getContact("123456").getFirstName());
    }

    @Test
    void testUpdateLastName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123456", "Jane", "Smith", "1110005555", "123 Drive St.");
        service.addContact(contact);
        service.updateLastName("123456", "Johnson");
        assertEquals("Johnson", service.getContact("123456").getLastName());
    }

    @Test
    void testUpdatePhoneNumber() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123456", "Jane", "Smith", "1110005555", "123 Drive St.");
        service.addContact(contact);
        service.updatePhoneNumber("123456", "2223334444");
        assertEquals("2223334444", service.getContact("123456").getPhoneNumber());
    }

    @Test
    void testUpdateAddress() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123456", "Jane", "Smith", "1110005555", "123 Drive St.");
        service.addContact(contact);
        service.updateAddress("123456", "456 Oak Ave.");
        assertEquals("456 Oak Ave.", service.getContact("123456").getContactAddress());
    }

    @Test
    void testUpdateContactNotFound() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("999999", "Emily"));
    }
}