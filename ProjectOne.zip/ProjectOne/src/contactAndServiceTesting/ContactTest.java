package contactAndServiceTesting;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contactAndService.Contact;

public class ContactTest {

    @Test
    void testContactNullArguments() {
        Assertions.assertThrows(IllegalArgumentException.class, () ->{
            new Contact(null, null, null, null, null);
        });
    }

    @Test
    void testContactAndGetters() {
        Contact contact = new Contact("123456", "Jane", "Smith", "1110005555", "123 Drive St.");
        assertEquals("123456", contact.getContactID());
        assertEquals("Jane", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("1110005555", contact.getPhoneNumber());
        assertEquals("123 Drive St.", contact.getContactAddress());
    }

    @Test
    void testSetFirstAndLastName() {
        Contact contact = new Contact("123456", "Jane", "Smith", "1110005555", "123 Drive St.");
        contact.setFirstName("Jane");
        contact.setLastName("Smith");
        assertEquals("Jane", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
    }

    @Test
    void testSetPhoneNumberAndAddress() {
        Contact contact = new Contact("123456", "Jane", "Smith", "1110005555", "123 Drive St.");
        contact.setPhoneNumber("1110005555");
        contact.setContactAddress("123 Drive St.");
        assertEquals("1110005555", contact.getPhoneNumber());
        assertEquals("123 Drive St.", contact.getContactAddress());
    }

    @Test
    void testNullSetAttributes() {
        Contact contact = new Contact("123456", "Jane", "Smith", "1110005555", "123 Drive St.");

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(null);
        });
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setContactAddress(null);
        });
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhoneNumber(null);
        });
    }
}