package appointmentAndTesting;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import appointmentAndService.Appointment;
import appointmentAndService.AppointmentService;

import java.util.Calendar;
import java.util.Date;


public class AppointmentServiceTest {
	
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        return cal.getTime();
    }
    
    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = getFutureDate();

        service.addAppointment(futureDate, "Doctor visit");
        Appointment appt = service.getAppointment("0");

        assertNotNull(appt);
        assertEquals("Doctor visit", appt.getDescription());
        assertEquals(futureDate, appt.getAppointmentDate());
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = getFutureDate();

        service.addAppointment(futureDate, "Dentist visit");
        service.deleteAppointment("0");

        assertNull(service.getAppointment("0"));
    }

    @Test
    public void testMultipleAppointmentsHaveUniqueIDs() {
        AppointmentService service = new AppointmentService();
        Date futureDate = getFutureDate();

        service.addAppointment(futureDate, "Meeting");
        service.addAppointment(futureDate, "Lunch");

        assertNotEquals(service.getAppointment("0").getAppointmentID(),
                        service.getAppointment("1").getAppointmentID());
    }

    @Test
    public void testDeleteNonexistentAppointmentDoesNothing() {
        AppointmentService service = new AppointmentService();
        service.deleteAppointment("999"); // nonexistent ID
        assertNull(service.getAppointment("999"));
    }
}
