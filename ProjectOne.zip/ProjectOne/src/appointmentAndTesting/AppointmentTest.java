package appointmentAndTesting;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import appointmentAndService.Appointment;

import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1); 
        return cal.getTime();
    }

    private Date getPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, -1);
        return cal.getTime();
    }

    @Test
    public void testValidAppointmentCreation() {
        Date future = getFutureDate();
        Appointment appt = new Appointment("123", future, "Dentist appointment");

        assertEquals("123", appt.getAppointmentID());
        assertEquals(future, appt.getAppointmentDate());
        assertEquals("Dentist appointment", appt.getDescription());
    }

    @Test
    public void testInvalidIDTooLong() {
        Date future = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", future, "Description"); // 11 chars
        });
    }

    @Test
    public void testInvalidIDNull() {
        Date future = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, future, "Description");
        });
    }

    @Test
    public void testInvalidDateNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", null, "Description");
        });
    }

    @Test
    public void testInvalidDatePast() {
        Date past = getPastDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", past, "Description");
        });
    }

    @Test
    public void testInvalidDescriptionNull() {
        Date future = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", future, null);
        });
    }

    @Test
    public void testInvalidDescriptionTooLong() {
        Date future = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", future,
                "This description is definitely more than fifty characters long and should fail.");
        });
    }

    @Test
    public void testSetValidDate() {
        Date future = getFutureDate();
        Appointment appt = new Appointment("123", future, "Description");

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 2);
        Date newFuture = cal.getTime();

        appt.setAppointmentDate(newFuture);
        assertEquals(newFuture, appt.getAppointmentDate());
    }

    @Test
    public void testSetInvalidDatePast() {
        Date future = getFutureDate();
        Appointment appt = new Appointment("123", future, "Description");

        Date past = getPastDate();
        assertThrows(IllegalArgumentException.class, () -> {
            appt.setAppointmentDate(past);
        });
    }

    @Test
    public void testSetValidDescription() {
        Date future = getFutureDate();
        Appointment appt = new Appointment("123", future, "Old description");

        appt.setDescription("New description");
        assertEquals("New description", appt.getDescription());
    }

    @Test
    public void testSetInvalidDescriptionTooLong() {
        Date future = getFutureDate();
        Appointment appt = new Appointment("123", future, "Old description");

        assertThrows(IllegalArgumentException.class, () -> {
            appt.setDescription("This description is definitely more than fifty characters long and should fail.");
        });
    }

}
