package contactAndService;

import java.util.ArrayList;
import java.util.List;

public class ContactService {

    private List<Contact> contacts = new ArrayList<>();

    private Contact findContact(String contactID) {
        for (Contact c : contacts) {
            if (c.getContactID().equals(contactID)) {
                return c;
            }
        }
        return null;
    }

    public void addContact(Contact contact) {
        if (findContact(contact.getContactID()) != null) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.add(contact);
    }

    public void deleteContact(String contactID) {
        Contact contact = findContact(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.remove(contact);
    }

    public void updateFirstName(String contactID, String firstName) {
        Contact contact = findContact(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contact.setFirstName(firstName);
    }

    public void updateLastName(String contactID, String lastName) {
        Contact contact = findContact(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contact.setLastName(lastName);
    }

    public void updatePhoneNumber(String contactID, String phoneNumber) {
        Contact contact = findContact(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contact.setPhoneNumber(phoneNumber);
    }

    public void updateAddress(String contactID, String address) {
        Contact contact = findContact(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contact.setContactAddress(address);
    }

    public Contact getContact(String contactID) {
        return findContact(contactID);
    }
}