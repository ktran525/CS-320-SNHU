package appointmentAndService;
import java.util.HashMap;
import java.util.Date;

public class AppointmentService {
	private final HashMap<String, Appointment> appointments = new HashMap<>();
	private int currentIDNum = 0;
	
	public void addAppointment(Date appointmentDate, String description) {
        String stringID = Integer.toString(currentIDNum);

        Appointment newAppointment = new Appointment(stringID, appointmentDate, description);
        appointments.put(stringID, newAppointment);

        currentIDNum++;
    }
	
	public void deleteAppointment(String appointmentID) {
        appointments.remove(appointmentID);
    }

    public Appointment getAppointment(String appointmentID) {
        return appointments.get(appointmentID);
    }
}
