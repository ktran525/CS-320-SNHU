package taskAndService;
import java.util.HashMap;

public class TaskService {
	
	int currentIDNum = 0;

	public final HashMap<String, Task> tasks = new HashMap<>();
	
    public void addUniqueTask(String name, String description) {
        String stringID = Integer.toString(currentIDNum);

        Task newTask = new Task(stringID, name, description);
        tasks.put(stringID, newTask);

        currentIDNum++;
	}
	
	public void deleteTask(String id) {
        tasks.remove(id);
	}
	
	public void updateTask(String id, String newName, String newDescription) {
		Task existingTask = tasks.get(id);
		
		if (existingTask != null) {
			existingTask.setName(newName);
			existingTask.setDescription(newDescription);
		}
	}
	
	public Task getTask(String id) {
        return tasks.get(id);
    }
}
