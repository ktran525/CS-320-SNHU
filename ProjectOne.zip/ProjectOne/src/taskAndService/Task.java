package taskAndService;

public class Task {
	
	private final String uniqueID;
	private String name;
	private String description;
	
	private boolean validateID(String uniqueID) {
        return uniqueID != null && uniqueID.length() <= 10;
    }

    private boolean validateName(String name) {
        return name != null && !name.isEmpty() && name.length() <= 20;
    }

    private boolean validateDescription(String description) {
        return description != null && !description.isEmpty() && description.length() <= 50;
    }
	
    public Task(String uniqueID, String name, String description) {
        if (!validateID(uniqueID)) {
            throw new IllegalArgumentException("Invalid ID: must be non-null and ? 10 characters.");
        }
        if (!validateName(name)) {
            throw new IllegalArgumentException("Invalid name: must be non-null and ? 20 characters.");
        }
        if (!validateDescription(description)) {
            throw new IllegalArgumentException("Invalid description: must be non-null and ? 50 characters.");
        }

        this.uniqueID = uniqueID;
        this.name = name;
        this.description = description;
    }

 
    public String getUniqueID() {
        return uniqueID;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    
    public void setName(String name) {
        if (!validateName(name)) {
            throw new IllegalArgumentException("Invalid name");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (!validateDescription(description)) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}