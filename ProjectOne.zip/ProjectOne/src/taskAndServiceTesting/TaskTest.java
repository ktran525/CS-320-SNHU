package taskAndServiceTesting;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import taskAndService.Task;

public class TaskTest {

	public void testTaskCreationValid() {
        Task task = new Task("123", "Test Name", "Test Description");
        assertEquals("123", task.getUniqueID());
        assertEquals("Test Name", task.getName());
        assertEquals("Test Description", task.getDescription());
    }
	
	public void testInvalidIDTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Description"); // 11 chars
        });
    }
	
	public void testInvalidIDNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Description");
        });
    }
	
	public void testInvalidNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "ThisNameIsWayTooLong", "Description");
        });
    }
	
	public void testInvalidNameEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "", "Description");
        });
    }
	
	public void testInvalidDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Name", "This description is more than fifty characters long.");
        });
    }
	
	public void testInvalidDescriptionEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Name", "");
        });
    }
	
    public void testSetNameValid() {
        Task task = new Task("123", "Old Name", "Description");
        task.setName("New Name");
        assertEquals("New Name", task.getName());
    }
    
    public void testSetNameInvalid() {
        Task task = new Task("123", "Old Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("");
        });
    }

    public void testSetDescriptionValid() {
        Task task = new Task("123", "Name", "Old Description");
        task.setDescription("New Description");
        assertEquals("New Description", task.getDescription());
    }

    public void testSetDescriptionInvalid() {
        Task task = new Task("123", "Name", "Old Description");
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("");
        });
    }
}

