package taskAndServiceTesting;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import taskAndService.TaskService;
import taskAndService.Task;

public class TaskServiceTest {
	
    public void testAddUniqueTask() {
        TaskService service = new TaskService();
        service.addUniqueTask("Task One", "First Description");

        Task task = service.getTask("0");
        assertNotNull(task);
        assertEquals("Task One", task.getName());
        assertEquals("First Description", task.getDescription());
    }

    public void testDeleteTask() {
        TaskService service = new TaskService();
        service.addUniqueTask("Task One", "Description");
        service.deleteTask("0");

        assertNull(service.getTask("0"));
    }

    public void testUpdateTask() {
        TaskService service = new TaskService();
        service.addUniqueTask("Original Name", "Original Description");

        service.updateTask("0", "Updated Name", "Updated Description");
        Task updated = service.getTask("0");

        assertEquals("Updated Name", updated.getName());
        assertEquals("Updated Description", updated.getDescription());
    }

    public void testUpdateNonexistentTask() {
        TaskService service = new TaskService();
        service.updateTask("999", "Name", "Description");

        assertNull(service.getTask("999"));
    }

    public void testMultipleTasksHaveUniqueIDs() {
        TaskService service = new TaskService();
        service.addUniqueTask("Task One", "Description One");
        service.addUniqueTask("Task Two", "Description Two");

        assertNotEquals(service.getTask("0").getUniqueID(), service.getTask("1").getUniqueID());
    }
}
